# Pipeline layer — main system, polling monitor, report generator
