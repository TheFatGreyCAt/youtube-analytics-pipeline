"""
Feature Engineering — tổng hợp tất cả features cho Model A (channel) và Model B (video).
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


# ─── Channel Feature Engineer ─────────────────────────────────────────────────
class ChannelFeatureEngineer:
    """
    Tính features cho kênh từ BigQuery data (training) và YouTube API data (inference).
    """

    REQUIRED_COLS = ["channel_id", "total_views", "total_likes", "total_comments",
                     "subscriber_count", "total_videos_crawled"]

    def fit(self, channel_df: pd.DataFrame) -> "ChannelFeatureEngineer":
        """
        Học phân bố từ training data để chuẩn hoá sau.

        Args:
            channel_df: int_channel_summary DataFrame (42 kênh).
        """
        self._check_cols(channel_df, self.REQUIRED_COLS)
        features = self._compute_base_features(channel_df)
        self._percentiles: dict[str, dict[str, float]] = {}
        for col in features.select_dtypes(include="number").columns:
            vals = features[col].dropna()
            if len(vals) == 0:
                continue
            self._percentiles[col] = {
                "p25": float(vals.quantile(0.25)),
                "p50": float(vals.quantile(0.50)),
                "p75": float(vals.quantile(0.75)),
                "mean": float(vals.mean()),
                "std": float(vals.std()),
                "min": float(vals.min()),
                "max": float(vals.max()),
            }
        logger.info("ChannelFeatureEngineer fitted pada %d kênh", len(channel_df))
        return self

    def transform(self, channel_df: pd.DataFrame, video_df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """Tính feature matrix từ BigQuery data.
        
        Args:
            channel_df: int_channel_summary
            video_df:   int_videos__enhanced (optional) — dùng để tính avg_views thực per video
        """
        self._check_cols(channel_df, self.REQUIRED_COLS)
        # Tính avg_views thực từ video_df thay vì total_views/videos_crawled
        channel_avg_map: dict[str, float] = {}
        if video_df is not None and "channel_id" in video_df.columns and "view_count" in video_df.columns:
            channel_avg_map = video_df.groupby("channel_id")["view_count"].mean().to_dict()
        return self._compute_base_features(channel_df, channel_avg_map)

    def transform_from_api(
        self,
        channel_stats: dict,
        video_stats: dict[str, dict],
    ) -> pd.DataFrame:
        """
        Tính features từ YouTube API data (kênh mới, không có trong BigQuery).

        Args:
            channel_stats: Kết quả từ YouTubeAPIClient.get_channel_stats()
            video_stats:   Kết quả từ YouTubeAPIClient.get_video_stats()

        Returns:
            DataFrame 1 dòng chứa features.
        """
        videos = list(video_stats.values())
        views_list = [v["views"] for v in videos if v.get("views", 0) > 0]

        subscribers = channel_stats.get("subscribers", 1) or 1
        video_count = channel_stats.get("video_count", 1) or 1
        total_likes = sum(v.get("likes", 0) for v in videos)
        total_comments = sum(v.get("comments", 0) for v in videos)

        # FIX: dùng tổng views từ CÙNG sample videos làm mẫu số
        # (tránh mismatch: likes từ 50 videos / total_views từ all-time channel = ratio ~0)
        total_views_sampled = sum(v.get("views", 0) for v in videos)
        total_views = total_views_sampled if total_views_sampled > 0 else channel_stats.get("total_views", 0) or 0

        avg_views = np.mean(views_list) if views_list else 0
        std_views = np.std(views_list) if len(views_list) > 1 else 0

        # Trend: 5 mới nhất vs 5 cũ hơn (videos đã sort by published_at desc)
        recent_trend = 1.0
        if len(views_list) >= 10:
            recent_avg = np.mean(views_list[:5])
            older_avg = np.mean(views_list[5:10])
            if older_avg > 0:
                recent_trend = recent_avg / older_avg

        features = self._build_channel_features(
            channel_id=channel_stats.get("channel_id", "unknown"),
            total_views=total_views,
            subscribers=subscribers,
            total_likes=total_likes,
            total_comments=total_comments,
            video_count=video_count,
            avg_views=avg_views,
            std_views=std_views,
            recent_trend=recent_trend,
        )
        return pd.DataFrame([features])

    # ── Private ────────────────────────────────────────────────────────────────
    def _compute_base_features(self, df: pd.DataFrame, channel_avg_map: dict | None = None) -> pd.DataFrame:
        import pandas as _pd
        def _safe(val, default=0):
            return default if (val is None or (_pd.isna(val) if not isinstance(val, str) else False)) else val

        if channel_avg_map is None:
            channel_avg_map = {}

        rows = []
        for _, row in df.iterrows():
            channel_id = row.get("channel_id", "")
            total_views = max(_safe(row.get("total_views"), 0), 1)
            subscribers = max(_safe(row.get("subscriber_count"), 1), 1)
            total_likes = _safe(row.get("total_likes"), 0)
            total_comments = _safe(row.get("total_comments"), 0)
            video_count = max(_safe(row.get("total_videos_crawled"), 1), 1)

            # Dùng avg_views từ video table nếu có (chính xác hơn total_views/videos_crawled)
            # vì total_views trong BQ là all-time channel views, không phải sum của videos crawled
            if channel_id in channel_avg_map:
                avg_views = float(channel_avg_map[channel_id])
            else:
                avg_views = total_views / video_count

            features = self._build_channel_features(
                channel_id=channel_id,
                total_views=total_views,
                subscribers=subscribers,
                total_likes=total_likes,
                total_comments=total_comments,
                video_count=video_count,
                avg_views=avg_views,
                std_views=0.0,    # không có từ summary — sẽ tính từ video data
                recent_trend=1.0, # không có từ summary
            )
            rows.append(features)
        return pd.DataFrame(rows)

    @staticmethod
    def _build_channel_features(
        channel_id: str,
        total_views: float,
        subscribers: float,
        total_likes: float,
        total_comments: float,
        video_count: float,
        avg_views: float,
        std_views: float,
        recent_trend: float,
    ) -> dict:
        subscribers = max(subscribers, 1)
        total_views = max(total_views, 1)
        avg_views = max(avg_views, 1)

        f1_efficiency = total_views / subscribers
        f2_loyalty = total_likes / total_views if total_views > 0 else 0
        f3_depth = total_comments / total_views if total_views > 0 else 0
        f6_avg_views = avg_views
        f7_engagement = f2_loyalty * 0.6 + f3_depth * 0.4

        # Consistency: 1 - CoV (cần std mới tính được, fallback = 0.5)
        f4_consistency = max(0.0, 1.0 - std_views / avg_views) if avg_views > 0 and std_views > 0 else 0.5

        f8_sub_count = subscribers
        f9_sub_tier = np.log10(subscribers) if subscribers > 0 else 0
        f10_recent_avg = avg_views  # fallback; sẽ override khi có full data
        f11_recent_trend = recent_trend

        return {
            "channel_id": channel_id,
            "f1_efficiency": f1_efficiency,
            "f2_loyalty": f2_loyalty,
            "f3_depth": f3_depth,
            "f4_consistency": f4_consistency,
            "f6_avg_views": f6_avg_views,
            "f7_engagement": f7_engagement,
            "f8_sub_count": f8_sub_count,
            "f9_sub_tier": f9_sub_tier,
            "f10_recent_avg": f10_recent_avg,
            "f11_recent_trend": f11_recent_trend,
        }

    @staticmethod
    def _check_cols(df: pd.DataFrame, required: list[str]) -> None:
        missing = [c for c in required if c not in df.columns]
        if missing:
            logger.warning("Thiếu cột: %s — sẽ dùng giá trị mặc định", missing)

    def get_feature_names(self) -> list[str]:
        return [
            "f1_efficiency", "f2_loyalty", "f3_depth", "f4_consistency",
            "f6_avg_views", "f7_engagement", "f8_sub_count", "f9_sub_tier",
            "f10_recent_avg", "f11_recent_trend",
        ]

    def get_percentiles(self) -> dict:
        """Trả về thống kê phân bố features từ training data (dùng để benchmark)."""
        if not hasattr(self, "_percentiles"):
            raise RuntimeError("Chưa gọi fit(). Hãy gọi fit(channel_df) trước.")
        return self._percentiles

    def get_percentile_rank(self, feature: str, value: float) -> float:
        """Tính percentile rank của value so với training distribution (0-100)."""
        if not hasattr(self, "_percentiles") or feature not in self._percentiles:
            return 50.0
        stats = self._percentiles[feature]
        if value <= stats["min"]:
            return 0.0
        if value >= stats["max"]:
            return 100.0
        # Linear interpolation giữa các percentile đã biết
        breakpoints = [
            (stats["min"], 0), (stats["p25"], 25),
            (stats["p50"], 50), (stats["p75"], 75), (stats["max"], 100)
        ]
        for i in range(len(breakpoints) - 1):
            lo_v, lo_p = breakpoints[i]
            hi_v, hi_p = breakpoints[i + 1]
            if lo_v <= value <= hi_v:
                if hi_v == lo_v:
                    return float(lo_p)
                return lo_p + (value - lo_v) / (hi_v - lo_v) * (hi_p - lo_p)
        return 50.0


# ─── Video Feature Engineer ───────────────────────────────────────────────────
class VideoFeatureEngineer:
    """
    Tính features cho video từ BigQuery data (training) và YouTube API data (inference).
    """

    def fit(
        self,
        engagement_df: pd.DataFrame,
        video_df: pd.DataFrame,
    ) -> "VideoFeatureEngineer":
        """
        Học channel baselines từ training data.

        Args:
            engagement_df: int_engagement_metrics
            video_df:      int_videos__enhanced
        """
        # Tính channel-level baselines từ video data
        if "channel_id" in video_df.columns and "view_count" in video_df.columns:
            grp = video_df.groupby("channel_id")["view_count"]
            self._channel_avg = grp.mean().to_dict()
            self._channel_std = grp.std().fillna(0).to_dict()
            self._channel_median = grp.median().to_dict()
        else:
            self._channel_avg = {}
            self._channel_std = {}
            self._channel_median = {}

        logger.info(
            "VideoFeatureEngineer fitted trên %d channels, %d videos",
            len(self._channel_avg),
            len(video_df),
        )
        return self

    def transform(
        self,
        engagement_df: pd.DataFrame,
        video_df: pd.DataFrame,
    ) -> pd.DataFrame:
        """Tính feature matrix từ BigQuery data."""
        # Merge để có đủ cột
        common_cols = list(set(engagement_df.columns) & set(video_df.columns))
        key_cols = [c for c in ["video_id", "channel_id", "view_count", "like_count",
                                 "comment_count"] if c in common_cols]
        merged = engagement_df.copy()
        if "duration_seconds" in video_df.columns and "video_id" in video_df.columns:
            extra = video_df[["video_id", "duration_seconds"]].drop_duplicates("video_id")
            merged = merged.merge(extra, on="video_id", how="left")

        import pandas as _pd
        def _safe(val, default=0):
            return default if (val is None or (_pd.isna(val) if not isinstance(val, str) else False)) else val

        rows = []
        for _, row in merged.iterrows():
            channel_id = row.get("channel_id", "")
            view_count = max(_safe(row.get("view_count"), 0), 1)
            like_count = _safe(row.get("like_count"), 0)
            comment_count = _safe(row.get("comment_count"), 0)
            duration_seconds = _safe(row.get("duration_seconds"), 0)
            engagement_score = _safe(row.get("engagement_score"), 0)

            channel_avg = self._channel_avg.get(channel_id, view_count)
            channel_std = self._channel_std.get(channel_id, 1)

            features = self._build_video_features(
                video_id=row.get("video_id", ""),
                channel_id=channel_id,
                views=view_count,
                likes=like_count,
                comments=comment_count,
                duration_seconds=duration_seconds,
                channel_avg_views=channel_avg,
                channel_std_views=channel_std,
                engagement_score=engagement_score,
            )
            rows.append(features)
        return pd.DataFrame(rows)

    def transform_from_api(
        self,
        video_data: dict,
        channel_stats: dict,
        video_stats_history: Optional[list[dict]] = None,
    ) -> pd.DataFrame:
        """
        Tính features từ API data cho video thực tế.

        Args:
            video_data:           Dict từ get_video_stats()[video_id]
            channel_stats:        Dict từ get_channel_stats()
            video_stats_history:  [{"views":..., "likes":..., "ts": ISO_str}] từ polling

        Returns:
            DataFrame 1 dòng.
        """
        views = video_data.get("views", 0) or 0
        likes = video_data.get("likes", 0) or 0
        comments = video_data.get("comments", 0) or 0
        duration_seconds = video_data.get("duration_seconds", 0) or 0

        subscribers = channel_stats.get("subscribers", 1) or 1
        video_count = channel_stats.get("video_count", 1) or 1

        # FIX: channel_avg_views từ BigQuery (nếu có) hoặc tính từ API call
        # Tránh dùng total_views(all-time) / video_count(total ever) → avg ảo
        channel_id = channel_stats.get("channel_id", "")
        bq_avg = self._channel_avg.get(channel_id, 0) if hasattr(self, "_channel_avg") else 0
        if bq_avg > 0:
            channel_avg_views = bq_avg  # avg từ int_videos__enhanced (chính xác nhất)
        else:
            # Fallback: ước tính từ API total_views và video_count
            total_views_api = channel_stats.get("total_views", views) or views
            channel_avg_views = total_views_api / video_count

        # Age
        published_at = video_data.get("published_at", "")
        age_hours = self._calc_age_hours(published_at)

        # Velocity
        views_per_hour = views / max(age_hours, 1)
        channel_hourly_avg = channel_avg_views / (30 * 24)
        velocity_ratio = views_per_hour / max(channel_hourly_avg, 1)

        features = self._build_video_features(
            video_id=video_data.get("video_id", ""),
            channel_id=channel_stats.get("channel_id", ""),
            views=views,
            likes=likes,
            comments=comments,
            duration_seconds=duration_seconds,
            channel_avg_views=channel_avg_views,
            channel_std_views=channel_avg_views * 0.5,  # ước tính
            engagement_score=(likes / max(views, 1)) * 100,
        )

        # Thêm real-time features
        features.update({
            "v7_views_at_poll": views,
            "v8_age_hours": age_hours,
            "v9_views_per_hour": views_per_hour,
            "v10_channel_hourly_avg": channel_hourly_avg,
            "v11_velocity_ratio": velocity_ratio,
        })

        # Early signal features từ polling history
        if video_stats_history:
            early = self._calc_early_signals(video_stats_history, published_at)
            features.update(early)

        return pd.DataFrame([features])

    # ── Private ────────────────────────────────────────────────────────────────
    @staticmethod
    def _build_video_features(
        video_id: str,
        channel_id: str,
        views: float,
        likes: float,
        comments: float,
        duration_seconds: float,
        channel_avg_views: float,
        channel_std_views: float,
        engagement_score: float = 0.0,
    ) -> dict:
        views = max(views, 1)
        channel_avg = max(channel_avg_views, 1)

        v1_like_ratio = likes / views
        v2_comment_ratio = comments / views
        v3_like_comment_ratio = likes / (comments + 1)
        v4_duration_mins = duration_seconds / 60 if duration_seconds else 0
        v5_relative_views = views / channel_avg
        v6_engagement_score = engagement_score

        # Log-transformed versions (robust to scale)
        log_views = np.log1p(views)
        log_channel_avg = np.log1p(channel_avg)
        log_relative = log_views - log_channel_avg

        return {
            "video_id": video_id,
            "channel_id": channel_id,
            "v1_like_ratio": v1_like_ratio,
            "v2_comment_ratio": v2_comment_ratio,
            "v3_like_comment_ratio": v3_like_comment_ratio,
            "v4_duration_mins": v4_duration_mins,
            "v5_relative_views": v5_relative_views,
            "v6_engagement_score": v6_engagement_score,
            "log_relative_views": log_relative,
            "log_views": log_views,
        }

    @staticmethod
    def _calc_age_hours(published_at: str) -> float:
        if not published_at:
            return 24.0
        try:
            pub = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            return max((now - pub).total_seconds() / 3600, 0.1)
        except Exception:
            return 24.0

    @staticmethod
    def _calc_early_signals(history: list[dict], published_at: str) -> dict:
        """Tính early signal features từ polling snapshots."""
        if not history:
            return {}

        pub_time = None
        if published_at:
            try:
                pub_time = datetime.fromisoformat(published_at.replace("Z", "+00:00"))
            except Exception:
                pass

        def get_views_at_hour(h: int) -> Optional[float]:
            if not pub_time:
                return None
            target = pub_time + __import__("datetime").timedelta(hours=h)
            closest = min(
                (s for s in history if "ts" in s),
                key=lambda s: abs(
                    (datetime.fromisoformat(s["ts"].replace("Z", "+00:00")) - target).total_seconds()
                ),
                default=None,
            )
            if closest and abs(
                (datetime.fromisoformat(closest["ts"].replace("Z", "+00:00")) - target).total_seconds()
            ) < 3 * 3600:  # trong vòng 3h là chấp nhận được
                return float(closest.get("views", 0))
            return None

        v6h = get_views_at_hour(6)
        v24h = get_views_at_hour(24)
        v48h = get_views_at_hour(48)

        result: dict = {}
        if v6h is not None:
            result["e1_views_6h"] = v6h
        if v24h is not None:
            result["e2_views_24h"] = v24h
        if v48h is not None:
            result["e3_views_48h"] = v48h
        if v6h and v24h and v6h > 0:
            result["e4_growth_rate_6_24"] = (v24h - v6h) / v6h
        if v24h and v48h and v24h > 0:
            result["e5_growth_rate_24_48"] = (v48h - v24h) / v24h

        return result

    def get_channel_avg(self, channel_id: str) -> float:
        return self._channel_avg.get(channel_id, 0.0)

    def get_video_feature_names(self) -> list[str]:
        return [
            "v1_like_ratio", "v2_comment_ratio", "v3_like_comment_ratio",
            "v4_duration_mins", "v5_relative_views", "v6_engagement_score",
            "log_relative_views", "log_views",
        ]
