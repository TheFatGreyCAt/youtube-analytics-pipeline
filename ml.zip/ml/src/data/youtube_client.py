"""
YouTube Data API v3 Client với quota tracking, caching và error handling.
Quota: 10,000 units/ngày (free tier).
  - Search: 100 units/call
  - Channel stats: 1 unit
  - Video list / stats: 1 unit per batch of 50
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

load_dotenv()

logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────
QUOTA_LIMIT = 10_000          # units/ngày
SEARCH_COST = 100             # units per search call
CHEAP_CALL_COST = 1           # units per channel/video call

CACHE_DIR = Path(__file__).parent.parent.parent / "cache"
CACHE_TTL: dict[str, int] = {
    "search": 6 * 3600,       # 6 giờ
    "channel": 24 * 3600,     # 24 giờ
    "videos": 3600,           # 1 giờ
    "video_stats": 3600,      # 1 giờ
}


# ─── Custom Exceptions ────────────────────────────────────────────────────────
class ChannelNotFoundError(Exception):
    """Không tìm thấy kênh YouTube."""


class QuotaExceededError(Exception):
    """Đã vượt quá quota API hàng ngày."""


# ─── File Cache ───────────────────────────────────────────────────────────────
class _FileCache:
    """Cache đơn giản dựa trên file JSON với TTL."""

    def __init__(self) -> None:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe_key = key.replace("/", "_").replace(":", "_")[:120]
        return CACHE_DIR / f"{safe_key}.json"

    def get(self, key: str, ttl: int) -> Optional[dict]:
        p = self._path(key)
        if not p.exists():
            return None
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if time.time() - data["_ts"] > ttl:
                return None
            return data["payload"]
        except Exception:
            return None

    def set(self, key: str, payload: dict) -> None:
        p = self._path(key)
        p.write_text(
            json.dumps({"_ts": time.time(), "payload": payload}, ensure_ascii=False),
            encoding="utf-8",
        )

    def clear(self) -> None:
        for f in CACHE_DIR.glob("*.json"):
            f.unlink(missing_ok=True)


# ─── Quota Tracker ────────────────────────────────────────────────────────────
class _QuotaTracker:
    """Theo dõi quota đã dùng trong ngày, lưu vào file."""

    def __init__(self) -> None:
        self._path = CACHE_DIR / "_quota_tracker.json"
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text())
            except Exception:
                pass
        return {"date": "", "used": 0}

    def _save(self, data: dict) -> None:
        self._path.write_text(json.dumps(data))

    def consume(self, units: int) -> None:
        data = self._load()
        today = datetime.now().strftime("%Y-%m-%d")
        if data["date"] != today:
            data = {"date": today, "used": 0}
        data["used"] += units
        self._save(data)
        logger.debug("Quota dùng hôm nay: %d / %d", data["used"], QUOTA_LIMIT)
        if data["used"] > QUOTA_LIMIT:
            raise QuotaExceededError(
                f"Đã vượt {QUOTA_LIMIT} units quota hôm nay. "
                "Thử lại vào ngày mai hoặc dùng API key khác."
            )

    @property
    def remaining(self) -> int:
        data = self._load()
        today = datetime.now().strftime("%Y-%m-%d")
        if data["date"] != today:
            return QUOTA_LIMIT
        return max(0, QUOTA_LIMIT - data["used"])


# ─── YouTube API Client ───────────────────────────────────────────────────────
class YouTubeAPIClient:
    """
    Wrapper cho YouTube Data API v3.

    Usage:
        client = YouTubeAPIClient()
        channel = client.search_channel("MrBeast")
        stats   = client.get_channel_stats(channel["channel_id"])
        videos  = client.get_recent_videos(channel["channel_id"], n=50)
    """

    def __init__(self, api_key: Optional[str] = None) -> None:
        key = api_key or os.getenv("YOUTUBE_API_KEY")
        if not key:
            raise ValueError(
                "YOUTUBE_API_KEY chưa được đặt. "
                "Thêm YOUTUBE_API_KEY=... vào file .env"
            )
        self._youtube = build("youtube", "v3", developerKey=key)
        self._cache = _FileCache()
        self._quota = _QuotaTracker()
        logger.info(
            "YouTubeAPIClient khởi tạo. Quota còn lại hôm nay: %d units",
            self._quota.remaining,
        )

    # ── Helpers ────────────────────────────────────────────────────────────────
    def _safe_int(self, val) -> int:
        try:
            return int(val)
        except (TypeError, ValueError):
            return 0

    def _parse_iso_duration(self, iso: str) -> int:
        """Chuyển ISO 8601 duration (PT1H2M3S) → giây."""
        import re
        if not iso:
            return 0
        pattern = r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?"
        m = re.match(pattern, iso)
        if not m:
            return 0
        h, mi, s = (int(x or 0) for x in m.groups())
        return h * 3600 + mi * 60 + s

    # ── Public Methods ─────────────────────────────────────────────────────────
    def search_channel(self, channel_name: str) -> dict:
        """
        Tìm kênh YouTube theo tên.

        Args:
            channel_name: Tên kênh (ví dụ: "MrBeast", "Nguyễn Hà Đông")

        Returns:
            {"channel_id": str, "channel_name": str, "description": str}

        Raises:
            ChannelNotFoundError: Không tìm thấy kênh.
            QuotaExceededError: Hết quota.
        """
        cache_key = f"search_{channel_name.lower().strip()}"
        cached = self._cache.get(cache_key, CACHE_TTL["search"])
        if cached:
            logger.debug("Cache hit: search_channel(%s)", channel_name)
            return cached

        self._quota.consume(SEARCH_COST)
        logger.info("🔍 Tìm kênh: %s (−%d quota)", channel_name, SEARCH_COST)

        try:
            resp = (
                self._youtube.search()
                .list(q=channel_name, type="channel", part="snippet", maxResults=5)
                .execute()
            )
        except HttpError as e:
            if e.resp.status == 403:
                raise QuotaExceededError(str(e)) from e
            raise

        items = resp.get("items", [])
        if not items:
            raise ChannelNotFoundError(f"Không tìm thấy kênh: '{channel_name}'")

        # Ưu tiên item có title khớp nhất (case-insensitive)
        best = items[0]
        for item in items:
            if item["snippet"]["channelTitle"].lower() == channel_name.lower():
                best = item
                break

        result = {
            "channel_id": best["snippet"]["channelId"],
            "channel_name": best["snippet"]["channelTitle"],
            "description": best["snippet"].get("description", ""),
        }
        self._cache.set(cache_key, result)
        return result

    def get_channel_stats(self, channel_id: str) -> dict:
        """
        Lấy thống kê kênh: subscriber, viewCount, videoCount.

        Returns:
            dict với các key: channel_id, channel_name, subscribers,
                              total_views, video_count, published_at
        """
        cache_key = f"channel_{channel_id}"
        cached = self._cache.get(cache_key, CACHE_TTL["channel"])
        if cached:
            return cached

        self._quota.consume(CHEAP_CALL_COST)
        logger.info("📊 Lấy stats: %s", channel_id)

        try:
            resp = (
                self._youtube.channels()
                .list(id=channel_id, part="statistics,snippet,contentDetails")
                .execute()
            )
        except HttpError as e:
            if e.resp.status == 403:
                raise QuotaExceededError(str(e)) from e
            raise

        items = resp.get("items", [])
        if not items:
            raise ChannelNotFoundError(f"channel_id không tồn tại: {channel_id}")

        item = items[0]
        stats = item["statistics"]
        snippet = item["snippet"]

        result = {
            "channel_id": channel_id,
            "channel_name": snippet.get("title", ""),
            "description": snippet.get("description", ""),
            "subscribers": self._safe_int(stats.get("subscriberCount")),
            "total_views": self._safe_int(stats.get("viewCount")),
            "video_count": self._safe_int(stats.get("videoCount")),
            "published_at": snippet.get("publishedAt", ""),
            "country": snippet.get("country", ""),
        }
        self._cache.set(cache_key, result)
        return result

    def get_recent_videos(self, channel_id: str, n: int = 50) -> list[dict]:
        """
        Lấy n video gần nhất của kênh.

        Returns:
            list of {"video_id": str, "title": str, "published_at": str}
        """
        cache_key = f"videos_{channel_id}_{n}"
        cached = self._cache.get(cache_key, CACHE_TTL["videos"])
        if cached:
            return cached

        self._quota.consume(CHEAP_CALL_COST)
        logger.info("🎬 Lấy %d video gần nhất: %s", n, channel_id)

        try:
            resp = (
                self._youtube.search()
                .list(
                    channelId=channel_id,
                    order="date",
                    type="video",
                    part="snippet",
                    maxResults=min(n, 50),
                )
                .execute()
            )
        except HttpError as e:
            if e.resp.status == 403:
                raise QuotaExceededError(str(e)) from e
            raise

        items = resp.get("items", [])
        result = [
            {
                "video_id": item["id"]["videoId"],
                "title": item["snippet"].get("title", ""),
                "published_at": item["snippet"].get("publishedAt", ""),
                "channel_id": channel_id,
            }
            for item in items
            if item.get("id", {}).get("videoId")
        ]
        self._cache.set(cache_key, result)
        return result

    def get_video_stats(self, video_ids: list[str]) -> dict[str, dict]:
        """
        Lấy statistics + contentDetails cho danh sách video.

        Args:
            video_ids: Tối đa 50 IDs mỗi lần gọi.

        Returns:
            {video_id: {"views": int, "likes": int, "comments": int,
                        "duration_seconds": int, "title": str,
                        "published_at": str, "tags": list}}
        """
        if not video_ids:
            return {}

        # Batch theo 50
        result: dict[str, dict] = {}
        for batch_start in range(0, len(video_ids), 50):
            batch = video_ids[batch_start : batch_start + 50]
            batch_key = f"vstats_{'_'.join(sorted(batch))}"
            cached = self._cache.get(batch_key, CACHE_TTL["video_stats"])
            if cached:
                result.update(cached)
                continue

            self._quota.consume(CHEAP_CALL_COST)
            try:
                resp = (
                    self._youtube.videos()
                    .list(
                        id=",".join(batch),
                        part="statistics,contentDetails,snippet",
                    )
                    .execute()
                )
            except HttpError as e:
                if e.resp.status == 403:
                    raise QuotaExceededError(str(e)) from e
                logger.error("Lỗi get_video_stats: %s", e)
                continue

            batch_result: dict[str, dict] = {}
            for item in resp.get("items", []):
                vid_id = item["id"]
                stats = item.get("statistics", {})
                content = item.get("contentDetails", {})
                snippet = item.get("snippet", {})
                batch_result[vid_id] = {
                    "video_id": vid_id,
                    "title": snippet.get("title", ""),
                    "published_at": snippet.get("publishedAt", ""),
                    "channel_id": snippet.get("channelId", ""),
                    "tags": snippet.get("tags", []),
                    "category_id": snippet.get("categoryId", ""),
                    "views": self._safe_int(stats.get("viewCount")),
                    "likes": self._safe_int(stats.get("likeCount")),
                    "comments": self._safe_int(stats.get("commentCount")),
                    "duration_seconds": self._parse_iso_duration(
                        content.get("duration", "")
                    ),
                }
            self._cache.set(batch_key, batch_result)
            result.update(batch_result)

        return result

    def get_channel_data_full(self, channel_name: str) -> dict:
        """
        One-shot: tìm kênh → lấy stats → lấy 50 video mới nhất → lấy video stats.
        Tiết kiệm nhất: 100 + 1 + 1 + 1 = 103 units.

        Returns:
            {
                "channel": {...},           # từ get_channel_stats
                "videos": [...],            # từ get_recent_videos
                "video_stats": {...},       # từ get_video_stats
            }
        """
        channel_info = self.search_channel(channel_name)
        channel_stats = self.get_channel_stats(channel_info["channel_id"])
        videos = self.get_recent_videos(channel_info["channel_id"], n=50)

        if videos:
            video_ids = [v["video_id"] for v in videos]
            video_stats = self.get_video_stats(video_ids)
        else:
            video_stats = {}

        logger.info(
            "✅ Hoàn thành fetch: %s — %d videos",
            channel_name,
            len(videos),
        )
        return {
            "channel": channel_stats,
            "videos": videos,
            "video_stats": video_stats,
        }

    def setup_polling(
        self, video_id: str, interval_hours: int = 6, duration_hours: int = 72
    ) -> None:
        """
        Ghi meta cho video vào cache để polling_monitor theo dõi.
        Không chạy background thread ở đây — dùng polling_monitor.py.
        """
        poll_meta = {
            "video_id": video_id,
            "interval_hours": interval_hours,
            "duration_hours": duration_hours,
            "start_time": datetime.utcnow().isoformat(),
            "snapshots": [],
        }
        self._cache.set(f"poll_{video_id}", poll_meta)
        logger.info("⏱  Polling setup cho video %s (mỗi %dh, trong %dh)", video_id, interval_hours, duration_hours)

    @property
    def quota_remaining(self) -> int:
        return self._quota.remaining


# ─── CLI ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
    channel_name = sys.argv[1] if len(sys.argv) > 1 else "MrBeast"

    client = YouTubeAPIClient()
    print(f"\nQuota còn lại: {client.quota_remaining} / {QUOTA_LIMIT} units")

    try:
        data = client.get_channel_data_full(channel_name)
        ch = data["channel"]
        print(f"\n📺 {ch['channel_name']} ({ch['channel_id']})")
        print(f"   Subscribers : {ch['subscribers']:,}")
        print(f"   Total views : {ch['total_views']:,}")
        print(f"   Videos      : {ch['video_count']:,}")
        print(f"   Videos fetch: {len(data['videos'])}")
    except ChannelNotFoundError as e:
        print(f"❌ {e}")
    except QuotaExceededError as e:
        print(f"⚠️  {e}")
