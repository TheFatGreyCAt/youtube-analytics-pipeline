"""
BigQuery Data Loader — tải 3 bảng intermediate layer cho ML training.
Tái sử dụng logic xác thực từ ml/fetch_data.py nhưng được đóng gói thành class
với caching, schema validation, và error handling đầy đủ.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Optional

import pandas as pd
from dotenv import load_dotenv
from google.cloud import bigquery
from google.oauth2 import service_account

load_dotenv()

logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────
INTERMEDIATE_SCHEMA = "intermediate"
LOCATION = "asia-southeast1"

REQUIRED_COLUMNS: dict[str, list[str]] = {
    "int_channel_summary": [
        "channel_id",
        "total_views",
        "total_likes",
        "total_comments",
        "subscriber_count",
        "total_videos_crawled",
    ],
    "int_engagement_metrics": [
        "video_id",
        "channel_id",
        "view_count",
        "like_count",
        "comment_count",
        "engagement_score",
    ],
    "int_videos__enhanced": [
        "video_id",
        "channel_id",
        "view_count",
        "like_count",
        "comment_count",
        "duration_seconds",
    ],
}


# ─── BigQueryLoader ────────────────────────────────────────────────────────────
class BigQueryLoader:
    """
    Load dữ liệu từ 3 bảng intermediate trên BigQuery.

    Usage:
        loader = BigQueryLoader()
        channel_df, engagement_df, video_df = loader.load_all()
    """

    def __init__(self) -> None:
        credentials_path = self._resolve_credentials()
        self.project_id = self._read_project_id(credentials_path)
        self.client = self._build_client(credentials_path)
        self._cache: dict[str, pd.DataFrame] = {}
        logger.info(
            "BigQueryLoader initialised | project=%s dataset=%s",
            self.project_id,
            INTERMEDIATE_SCHEMA,
        )

    # ── Private helpers ────────────────────────────────────────────────────────
    @staticmethod
    def _resolve_credentials() -> str:
        """Tìm service-account JSON từ env hoặc thư mục credentials/."""
        path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        if path and Path(path).exists():
            return path

        creds_dir = Path(__file__).parent.parent.parent.parent / "credentials"
        if creds_dir.exists():
            json_files = list(creds_dir.glob("*.json"))
            if json_files:
                return str(json_files[0])

        raise FileNotFoundError(
            "Không tìm thấy credentials. "
            "Đặt GOOGLE_APPLICATION_CREDENTIALS trong .env hoặc để file JSON vào credentials/"
        )

    @staticmethod
    def _read_project_id(credentials_path: str) -> str:
        with open(credentials_path) as f:
            return json.load(f)["project_id"]

    @staticmethod
    def _build_client(credentials_path: str) -> bigquery.Client:
        project_id = BigQueryLoader._read_project_id(credentials_path)
        credentials = service_account.Credentials.from_service_account_file(
            credentials_path,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        return bigquery.Client(
            credentials=credentials,
            project=project_id,
            location=LOCATION,
        )

    def _full_table(self, table_name: str) -> str:
        return f"`{self.project_id}.{INTERMEDIATE_SCHEMA}.{table_name}`"

    # ── Public API ─────────────────────────────────────────────────────────────
    def fetch_table(
        self,
        table_name: str,
        limit: Optional[int] = None,
        use_cache: bool = True,
    ) -> pd.DataFrame:
        """
        Tải một bảng BigQuery về DataFrame.

        Args:
            table_name: Tên bảng (không có project/dataset prefix).
            limit: Giới hạn số dòng (None = lấy tất cả).
            use_cache: Dùng cache in-memory nếu đã load trước đó.

        Returns:
            DataFrame. Trả về DataFrame rỗng nếu bảng không tồn tại / lỗi.
        """
        cache_key = f"{table_name}_{limit}"
        if use_cache and cache_key in self._cache:
            logger.debug("Cache hit: %s", table_name)
            return self._cache[cache_key].copy()

        limit_clause = f"LIMIT {limit}" if limit else ""
        query = f"SELECT * FROM {self._full_table(table_name)} {limit_clause}"

        try:
            logger.info("Đang tải bảng %s ...", table_name)
            df = self.client.query(query).to_dataframe()
            self._validate_columns(df, table_name)
            self._cache[cache_key] = df
            logger.info("✅ %s — %d dòng × %d cột", table_name, len(df), len(df.columns))
            return df
        except Exception as exc:
            logger.error("❌ Lỗi khi tải %s: %s", table_name, exc)
            return pd.DataFrame()

    def _validate_columns(self, df: pd.DataFrame, table_name: str) -> None:
        required = REQUIRED_COLUMNS.get(table_name, [])
        missing = [c for c in required if c not in df.columns]
        if missing:
            logger.warning(
                "Bảng %s thiếu cột: %s",
                table_name,
                missing,
            )

    def load_channel_summary(self, limit: Optional[int] = None) -> pd.DataFrame:
        """Tải int_channel_summary — 42 kênh, training base cho Model A."""
        return self.fetch_table("int_channel_summary", limit=limit)

    def load_engagement_metrics(self, limit: Optional[int] = None) -> pd.DataFrame:
        """Tải int_engagement_metrics — 1,000 video, dùng để train Model B."""
        return self.fetch_table("int_engagement_metrics", limit=limit)

    def load_videos_enhanced(self, limit: Optional[int] = None) -> pd.DataFrame:
        """Tải int_videos__enhanced — 1,000 video với duration và metadata."""
        return self.fetch_table("int_videos__enhanced", limit=limit)

    def load_all(
        self, limit: Optional[int] = None
    ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Tải cả 3 bảng cùng lúc.

        Returns:
            (channel_summary_df, engagement_metrics_df, videos_enhanced_df)
        """
        print("\n" + "=" * 60)
        print("🚀 LOADING BIGQUERY INTERMEDIATE LAYER")
        print("=" * 60)
        channel_df = self.load_channel_summary(limit=limit)
        engagement_df = self.load_engagement_metrics(limit=limit)
        video_df = self.load_videos_enhanced(limit=limit)

        print(f"\n📦 Tóm tắt dữ liệu đã tải:")
        print(f"  int_channel_summary    → {len(channel_df):4d} dòng × {len(channel_df.columns)} cột")
        print(f"  int_engagement_metrics → {len(engagement_df):4d} dòng × {len(engagement_df.columns)} cột")
        print(f"  int_videos__enhanced   → {len(video_df):4d} dòng × {len(video_df.columns)} cột\n")
        return channel_df, engagement_df, video_df

    def print_schema(self) -> None:
        """In ra tên cột của từng bảng — dùng để inspect data trước training."""
        tables = {
            "int_channel_summary": self.load_channel_summary(limit=1),
            "int_engagement_metrics": self.load_engagement_metrics(limit=1),
            "int_videos__enhanced": self.load_videos_enhanced(limit=1),
        }
        print("\n" + "=" * 70)
        print("📋 SCHEMA — INTERMEDIATE LAYER")
        print("=" * 70)
        for table_name, df in tables.items():
            if df.empty:
                print(f"\n⚠️  {table_name}: không tải được")
                continue
            print(f"\n▌ {table_name} ({len(df.columns)} cột)")
            print(f"  {'Cột':<35} {'Dtype':<20}")
            print(f"  {'─'*35} {'─'*20}")
            for col, dtype in df.dtypes.items():
                print(f"  {col:<35} {str(dtype):<20}")


# ─── CLI ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
    loader = BigQueryLoader()
    loader.print_schema()
    channel_df, engagement_df, video_df = loader.load_all()
    print(channel_df.head(3).to_string())
