# Data layer — BigQuery loader, YouTube API client, feature engineering
